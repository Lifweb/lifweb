<!-- footer styles -->

<style> .u-footer {
  background-image: none;
}
.u-footer .u-sheet-1 {
  min-height: 120px;
}
.u-footer .u-text-1 {
  width: 417px;
  margin: 49px auto;
}
@media (max-width: 575px) {
  .u-footer .u-text-1 {
    width: 340px;
  }
}</style>
