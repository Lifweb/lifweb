<!-- ThankYou styles -->


<style> .u-section-1 {
  background-image: none;
}
.u-section-1 .u-sheet-1 {
  min-height: 800px;
}
.u-section-1 .u-text-1 {
  margin: 60px auto 0;
}
.u-section-1 .u-text-2 {
  margin: 20px auto 60px;
}
</style>
